export interface ICommonError{
    id: string;
    date: Date;
    description: string;
}